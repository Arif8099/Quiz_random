import os
import pymysql
import json

def lambda_handler(event, context):
    # Database connection parameters from environment variables
    db_host = os.environ['DB_HOST']
    db_user = os.environ['DB_USER']
    db_password = os.environ['DB_PASSWORD']
    db_name = os.environ['DB_NAME']

    try:
        # Establish a database connection
        connection = pymysql.connect(
            host=db_host,
            user=db_user,
            password=db_password,
            database=db_name,
            cursorclass=pymysql.cursors.DictCursor
        )

        with connection.cursor() as cursor:
            # SQL query to retrieve all entries ordered by correct_answers descending
            query = """
                SELECT * FROM participant_responses
                ORDER BY correct_answers DESC;
            """
            cursor.execute(query)
            results = cursor.fetchall()

        # Return the results as a JSON response
        return {
            'statusCode': 200,
            'body': json.dumps(results)
        }

    except Exception as e:
        # Handle any errors that occur during the database operation
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }

    finally:
        # Ensure the database connection is closed
        if 'connection' in locals():
            connection.close()
