import os
import pymysql
import json

def lambda_handler(event, context):
    # Retrieve database connection parameters from environment variables
    db_host = os.environ['DB_HOST']
    db_user = os.environ['DB_USER']
    db_password = os.environ['DB_PASSWORD']
    db_name = os.environ['DB_NAME']

    # Parse the incoming JSON payload
    try:
        body = json.loads(event['body'])
        name = body['name']
        total_questions = body['total_questions']
        correct_answers = body['correct_answers']
        user_answers = body['user_answers']  # List of 10 answers
        actual_answers = body['actual_answers']  # List of 10 answers
    except (KeyError, json.JSONDecodeError) as e:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': f'Invalid input: {str(e)}'})
        }

    # Establish a connection to the RDS database
    try:
        connection = pymysql.connect(
            host=db_host,
            user=db_user,
            password=db_password,
            database=db_name,
            cursorclass=pymysql.cursors.DictCursor
        )
    except pymysql.MySQLError as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': f'Database connection failed: {str(e)}'})
        }

    # Insert data into the participant_responses table
    try:
        with connection.cursor() as cursor:
            sql = """
                INSERT INTO participant_responses (
                    name, total_questions, correct_answers,
                    user_answer_1, user_answer_2, user_answer_3, user_answer_4, user_answer_5,
                    user_answer_6, user_answer_7, user_answer_8, user_answer_9, user_answer_10,
                    actual_answer_1, actual_answer_2, actual_answer_3, actual_answer_4, actual_answer_5,
                    actual_answer_6, actual_answer_7, actual_answer_8, actual_answer_9, actual_answer_10
                ) VALUES (
                    %s, %s, %s,
                    %s, %s, %s, %s, %s,
                    %s, %s, %s, %s, %s,
                    %s, %s, %s, %s, %s,
                    %s, %s, %s, %s, %s
                );
            """
            cursor.execute(sql, (
                name, total_questions, correct_answers,
                *user_answers,
                *actual_answers
            ))
            connection.commit()
    except pymysql.MySQLError as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': f'Failed to insert data: {str(e)}'})
        }
    finally:
        connection.close()

    return {
        'statusCode': 200,
        'body': json.dumps({'message': 'Data inserted successfully'})
    }
